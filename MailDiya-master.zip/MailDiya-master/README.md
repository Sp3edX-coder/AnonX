<h1 align="center">MailDiya

</h1>
<p align="center">An open-source Anonymous E-Mail Sender And E-Mail Bombing tool.</p><br>


###############  Coded by      : tuhin1729 ##############<br>
########### Inspired by        : Charlie:The Hacker ##############<br>
##############  Instagram id   : www.instagram.com/tuhin1729 ##############<br>
##############  Github         : www.github.com/tuhin1729 ##############<br>
############## YouTube Channel : https://bit.ly/TuhinTheHacker ##############<br>
############## Dedicated to    : Diya Saha ##############<br>



#### By Changing the name, You won't be a script developer...

## Note:

- The script requires working network connection to work.
- While running this script, a vpn must be used.
- This script is only for educational purposes.
- **Developer is not responsible for the misuse of MailDiya.**
<br>

## Features:

- Anonymous E-Mail sending.
- E-Mail bombing without logging in.
- Easy to use.

## Usage:

Run these commands to run MailDiya

### > For Termux:

**Notice:** 

git installation methods are not universal and do differ between distributions,
so, installing git as per instructions below may not work.
Please check out how to install `git` for your Linux distribution.
Commands below provide instructions for Debian-based systems.

To use the scanner type the following commands in Termux:
```
pkg install git
pkg install python2
git clone https://github.com/tuhin1729/MailDiya.git
cd MailDiya
pip2 install -r requirements.txt
python2 maildiya.py
```

### > For Linux:

**Notice:** 

To use the scanner type the following commands in Linux terminal:
```
git clone https://github.com/tuhin1729/MailDiya.git
cd MailDiya
pip install -r requirements.txt
python2 maildiya.py
```



# CONTACT ME:

Feel Free To Open An Issue...

```
                 Instagram id: @tuhin1729
       YouTube Channel : https://bit.ly/TuhinTheHacker
```


